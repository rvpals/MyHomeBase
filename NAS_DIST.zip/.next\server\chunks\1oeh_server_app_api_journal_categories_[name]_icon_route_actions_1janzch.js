module.exports=[306709,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_journal_categories_%5Bname%5D_icon_route_actions_1janzch.js.map