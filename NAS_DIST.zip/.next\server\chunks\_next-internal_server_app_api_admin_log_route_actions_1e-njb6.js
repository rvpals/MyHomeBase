module.exports=[257391,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_log_route_actions_1e-njb6.js.map