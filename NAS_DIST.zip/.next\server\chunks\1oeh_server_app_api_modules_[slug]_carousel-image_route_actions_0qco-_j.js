module.exports=[742969,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_modules_%5Bslug%5D_carousel-image_route_actions_0qco-_j.js.map