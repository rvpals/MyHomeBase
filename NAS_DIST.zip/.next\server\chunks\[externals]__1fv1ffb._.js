module.exports=[449719,(e,r,s)=>{r.exports=e.x("assert",()=>require("assert"))},500874,(e,r,s)=>{r.exports=e.x("buffer",()=>require("buffer"))},522734,(e,r,s)=>{r.exports=e.x("fs",()=>require("fs"))},688947,(e,r,s)=>{r.exports=e.x("stream",()=>require("stream"))},406461,(e,r,s)=>{r.exports=e.x("zlib",()=>require("zlib"))}];

//# sourceMappingURL=%5Bexternals%5D__1fv1ffb._.js.map