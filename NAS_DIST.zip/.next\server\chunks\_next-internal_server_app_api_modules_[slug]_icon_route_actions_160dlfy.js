module.exports=[661257,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_modules_%5Bslug%5D_icon_route_actions_160dlfy.js.map