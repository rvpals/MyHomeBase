module.exports=[316114,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_documents_%5Bid%5D_attachments_route_actions_1hi79cz.js.map