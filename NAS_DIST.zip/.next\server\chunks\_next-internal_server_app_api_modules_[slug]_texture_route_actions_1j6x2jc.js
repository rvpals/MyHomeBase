module.exports=[758975,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_modules_%5Bslug%5D_texture_route_actions_1j6x2jc.js.map