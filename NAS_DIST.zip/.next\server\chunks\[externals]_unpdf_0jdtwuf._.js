module.exports=[48353,a=>a.a(async(t,c)=>{try{var e=await a.y("unpdf-968ffb9b8a880814");a.n(e),c()}catch(a){c(a)}},!0)];

//# sourceMappingURL=%5Bexternals%5D_unpdf_0jdtwuf._.js.map