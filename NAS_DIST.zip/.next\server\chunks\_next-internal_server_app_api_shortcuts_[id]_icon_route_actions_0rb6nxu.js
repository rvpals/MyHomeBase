module.exports=[151590,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_shortcuts_%5Bid%5D_icon_route_actions_0rb6nxu.js.map