module.exports=[887540,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_admin_locations_categories_%5Bname%5D_icon_route_actions_18qeqjo.js.map