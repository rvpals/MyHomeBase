module.exports=[804851,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_expense_accounts_%5Bid%5D_image_route_actions_1wpas37.js.map