module.exports=[204514,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_expense_categories_%5Bname%5D_icon_route_actions_1zictyi.js.map