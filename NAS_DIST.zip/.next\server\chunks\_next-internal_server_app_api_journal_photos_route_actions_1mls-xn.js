module.exports=[92724,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_journal_photos_route_actions_1mls-xn.js.map