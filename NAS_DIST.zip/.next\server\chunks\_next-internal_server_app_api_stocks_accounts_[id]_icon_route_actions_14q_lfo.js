module.exports=[583136,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_accounts_%5Bid%5D_icon_route_actions_14q_lfo.js.map