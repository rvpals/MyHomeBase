module.exports=[768842,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_household_hsa_%5Bid%5D_receipt_route_actions_205saj6.js.map