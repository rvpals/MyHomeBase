var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1vwsrry._.js")
R.c("server/chunks/[root-of-the-server]__0quekr0._.js")
R.m(489997)
module.exports=R.m(489997).exports
