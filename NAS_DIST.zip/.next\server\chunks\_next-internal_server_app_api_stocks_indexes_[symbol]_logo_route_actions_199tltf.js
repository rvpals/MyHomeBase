module.exports=[640909,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_indexes_%5Bsymbol%5D_logo_route_actions_199tltf.js.map