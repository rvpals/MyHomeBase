module.exports=[217648,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_expense_vendors_%5Bname%5D_icon_route_actions_0-fsjll.js.map