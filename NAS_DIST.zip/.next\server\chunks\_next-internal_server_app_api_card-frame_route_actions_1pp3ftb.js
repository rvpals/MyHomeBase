module.exports=[522565,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_card-frame_route_actions_1pp3ftb.js.map