module.exports=[740584,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_journal_tags_%5Bname%5D_icon_route_actions_1ksxfq5.js.map