module.exports=[767672,(a,e,c)=>{e.exports=a.x("@napi-rs/canvas-1a9ce9c965db10fa",()=>require("@napi-rs/canvas-1a9ce9c965db10fa"))}];

//# sourceMappingURL=%5Bexternals%5D_%40napi-rs_canvas_1f_wkhu._.js.map