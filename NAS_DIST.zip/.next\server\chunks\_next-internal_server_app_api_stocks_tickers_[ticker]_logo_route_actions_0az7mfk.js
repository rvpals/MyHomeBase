module.exports=[393929,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_tickers_%5Bticker%5D_logo_route_actions_0az7mfk.js.map