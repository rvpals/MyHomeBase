module.exports=[81737,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_documents_categories_%5Bname%5D_icon_route_actions_0bjqdin.js.map