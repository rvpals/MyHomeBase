module.exports=[991770,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_journal_photos_zip_route_actions_0nq2o0b.js.map