module.exports=[316741,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_app-version_route_actions_01rg52p.js.map