module.exports=[876314,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_texture_route_actions_1y-0ttb.js.map