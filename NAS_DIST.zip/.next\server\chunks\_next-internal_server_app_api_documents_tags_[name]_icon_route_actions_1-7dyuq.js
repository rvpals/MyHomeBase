module.exports=[737881,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_documents_tags_%5Bname%5D_icon_route_actions_1-7dyuq.js.map