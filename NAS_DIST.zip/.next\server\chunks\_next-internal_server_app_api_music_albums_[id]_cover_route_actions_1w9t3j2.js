module.exports=[178934,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_music_albums_%5Bid%5D_cover_route_actions_1w9t3j2.js.map