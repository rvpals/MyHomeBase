module.exports=[896216,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_icons_slots_%5Bslot%5D_route_actions_1iczx0w.js.map