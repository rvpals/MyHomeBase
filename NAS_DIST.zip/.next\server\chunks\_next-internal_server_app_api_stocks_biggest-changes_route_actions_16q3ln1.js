module.exports=[309163,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_biggest-changes_route_actions_16q3ln1.js.map