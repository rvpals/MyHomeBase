module.exports=[179580,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clips_images_%5Bid%5D_route_actions_1wzq5oa.js.map