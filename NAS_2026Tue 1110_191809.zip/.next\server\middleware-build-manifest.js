globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/A9d_5VcA_rQX7a6BG6iGz/_buildManifest.js",
    "static/A9d_5VcA_rQX7a6BG6iGz/_ssgManifest.js",
    "static/A9d_5VcA_rQX7a6BG6iGz/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0wf2rmyoojkx7.js",
    "static/chunks/0if-vqkhyn-zc.js",
    "static/chunks/0k5mu6ti-ff21.js",
    "static/chunks/1vgpv7vwitdbl.js",
    "static/chunks/turbopack-0udhsan0k5c0e.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
